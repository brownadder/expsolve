#from .classical import classical, symmetric, consistent
import expsolve.splittings.classical