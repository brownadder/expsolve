# expsolve

This package provides tools for creating exponential solvers such as exponential splittings, exponential integrators, Magnus expansion based methods etc. for solving dispersive PDEs, particularly PDEs of quantum mechanics. 

Current functionality is limited to Fourier discretisation in space. Please see examples directory for tutorial notebooks. 
